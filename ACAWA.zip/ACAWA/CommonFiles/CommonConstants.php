<?php

define("SUBJ_NAME_LENGTH",45);
define("TEACHER_NAME_LENGTH",50);
define("IMAGELINK_LENGTH",100);
define("FILE_LINK_LENGTH",100);
define("USER_NAME_LENGTH",45);
define("UNAME_LENGTH",20);
define("BRANCH_LENGTH",30);
define("PROFILEPIC_LINK_LENGTH",100);
define("NO_OF_STD_IMAGES",17);
define("NO_OF_SEMS",5);
define("RETRY_MAIL_LIMIT",3);

?>