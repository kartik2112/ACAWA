<meta name="theme-color" content="#ee6e73">
<link rel="icon" sizes="192x192" href="images/logo.PNG"> 
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<link type="text/css" rel="stylesheet" href="CommonFiles/MainUIChanges.css" />
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="materialize/css/materialize.css">
<script src="materialize/js/materialize.js"></script>